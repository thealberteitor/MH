#include <stdio.h>

#include "anneal.h"
#include "random_ppio.h"

float Funcion_objetivo (int solucion[], int n_bits)
{
   int i, fobj = 0;

   for (i=0; i<n_bits; i++)
   fobj += solucion[i];

   return fobj;
}

int main (void)
{
   int n_bits;
   int *sol_inicial;
   int f;

   /* Las siguientes variables son los parametros del annealing:
      t_inicial -> Temperatura inicial.
      n_enfriamientos -> Numero maximo de enfriamientos de la temperatura
                         a realizar.
      max_vecinos -> Numero maximo de vecinos a generar en cada iteracion 
                     (para cada valor de la temperatura) antes de enfriarla.
      max_exitos -> Numero de exitos a generar en cada iteracion 
                    (para cada valor de la temperatura) antes de enfriarla.
                    Se contabiliza un exito por cada vecino aceptado, ya sea
                    directamente o probabilisticamente por el criterio de
                    Metropolis.
                    
     De este modo, el annealing salta a la siguiente iteracion, es decir, enfria
     la temperatura, cuando se hayan generado max_vecinos O se hayan contabilizado
     max_exitos (lo primero que ocurra) para la temperatura actual.
     
     En cambio, el algoritmo finaliza su ejecucion cuando se han realizado
     n_enfriamientos iteraciones (es decir, se ha enfriado la temperatura
     n_enfriamientos veces) O cuando para una temperatura no se ha contabilizado
     ningun exito (lo que ocurra antes). */
   
   int n_enfriamientos;
   float max_vecinos, max_exitos, t_inicial;

   n_bits = 500;

   /* Inicializacion de los parametros del algoritmo */
   max_vecinos = 100 * n_bits;
   max_exitos = 10 * n_bits;
   t_inicial = 0.5;
   n_enfriamientos = 100;

   /* Inicializacion de la semilla para el generador de numeros aleatorios */
   Set_random(12345678L);

   sol_inicial= (int *) malloc (n_bits*sizeof(int));
   if (sol_inicial==NULL) {
      printf("\nERROR DE MEMORIA.\n");
      abort();
   }

   /* Generacion de la solucion inicial */
   for (f=0; f<n_bits; f++)
      sol_inicial[f] = Randint(0,1);

   /* Llamada a la rutina que implementa el algoritmo SA */
   anneal(sol_inicial,n_bits,n_enfriamientos,t_inicial,max_vecinos,max_exitos);

   /* Escritura en pantalla de la solucion obtenida, asi como de su costo */
   printf ("\nSolucion final:\n");
   for (f=0; f<n_bits; f++)
      printf ("%d ",sol_inicial[f]);
   printf ("\nValor objetivo: %f\n\n",Funcion_objetivo(sol_inicial,n_bits));

   free (sol_inicial);

   return (0); 
}
