#include <stdio.h>
#include "anneal.h"
#include "random_ppio.h"

int metrop (float de, float t)
/* Implementacion del criterio de Metropolis. Devuelve 1 si el vecino
   es aceptado y 0 en caso contrario. Acepta automaticamente dicho
   vecino si es mejor que la solucion actual (es decir, si
   de = F(Sactual) - F(Snueva) es negativo). En caso contrario, lo
   acepta o rechaza probabilisticamente en funcion del valor de la
   temperatura, t, y la diferencia de costos, de. */
{
    return de < 0.0 || Rand() < exp(-de/t);
}

void Genera_Vecino (int *sol_act, int *vecino, int n_bits, int *pos)
/* Operador de vecino. Se genera una posicion aleatoriamente y se invierte el
   valor binario, de 0 se pasa a 1, o de 1 se pasa a 0 */
{
   int i;

   for (i=0; i<n_bits; i++)
      vecino[i] = sol_act[i];

   *pos = Randint(0,n_bits-1);
   vecino[*pos] = !vecino[*pos];
}

void anneal (int *sol_act, int n_bits, int n_enfriamientos,
             float t, float max_vecinos, float max_exitos)
/* Parametros:
      x,y -> Vectores que almacenan las coordenadas de las
             ciudades en el plano.
      sol_act -> solucion actual del algoritmo (al principio 
                  contiene la solucion inicial de la que parte).
      n_ciudades -> numero de ciudades del caso del problema.
      t -> Temperatura (al principio contiene el valor de la
           temperatura inicial).
      n_enfriamientos -> Numero maximo de enfriamientos de la temperatura
                         a realizar.
      max_vecinos -> Numero maximo de vecinos a generar en cada iteracion 
                   (para cada valor de la temperatura) antes de enfriarla.
      max_exitos -> Numero de exitos a generar en cada iteracion 
                  (para cada valor de la temperatura) antes de enfriarla.
                    Se contabiliza un exito por cada vecino aceptado, ya sea
                    directamente o probabilisticamente por el criterio de
                    Metropolis.

   De este modo, el annealing salta a la siguiente iteracion, es decir, enfria
   la temperatura, cuando se hayan generado max_vecinos O se hayan contabilizado
   max_exitos (lo primero que ocurra) para la temperatura actual.
     
   En cambio, el algoritmo finaliza su ejecucion cuando se han realizado
   n_enfriamientos iteraciones (es decir, se ha enfriado la temperatura
   n_enfriamientos veces) O cuando para una temperatura no se ha contabilizado
   ningun exito (lo que ocurra antes). */

{
   int i, j, k, n_exitos, aceptar, pos;
   int *vecino, *mejor_sol;
   float fobj_act, fobj_vecino, fobj_mejor, de;

   /* Reserva de memoria para las estructuras que almacenan el
      vecino generado para la solucion actual y la mejor solucion
      hallada hasta el momento en la exploracion del espacio */
   vecino = (int *) malloc (n_bits*sizeof(int));
   if (vecino==NULL) {
      printf("\nERROR DE MEMORIA.\n");
      abort();
   }

   mejor_sol= (int *) malloc (n_bits*sizeof(int));
   if (mejor_sol==NULL) {
      printf("\nERROR DE MEMORIA.\n");
      abort();
   }

   /* Calculo de la funcion objetivo de la solucion inicial e inicializacion de la
      mejor solucion encontrada hasta el momento a la solucion inicial */
   fobj_act = Funcion_objetivo(sol_act,n_bits);
   fobj_mejor = fobj_act;
   for (i=0; i<n_bits; i++)
      mejor_sol[i]=sol_act[i];

    /* Bucle principal del SA */
   for (j=1; j<=n_enfriamientos; j++) {
      /* Inicializamos el contador de exitos a 0 para la temperatura actual. */
      n_exitos=0;

      /* Bucle interno: generacion de vecinos para la temperatura actual.
         Finaliza cuando se hayan generado max_vecinos o cuando se hayan
         contabilizado max_exitos. */
      for (k=1; k<=max_vecinos; k++) {
      
         /* Obtencion de un vecino de la solucion actual por inversion */
         Genera_Vecino (sol_act, vecino, n_bits, &pos);

         /* Estudiamos si el nuevo vecino es aceptado */
         fobj_vecino = Funcion_objetivo (vecino,n_bits);
         de = fobj_act - fobj_vecino;
         aceptar = metrop(de,t);

         /* En el caso en que el nuevo vecino es aceptado: */
         if (aceptar) {
            /* Contamos un nuevo exito */
            n_exitos++;

            /* Actualizamos la solucion actual */
            fobj_act = fobj_vecino;
            for (i=0; i<n_bits; i++)
                sol_act[i] = vecino[i];

            /* Actualizamos la mejor solucion hallada hasta el momento */
            if (fobj_act > fobj_mejor) {
                fobj_mejor = fobj_act;
                for (i=0; i<n_bits; i++)
                    mejor_sol[i] = sol_act[i];
            }
         }

         /* Saltamos a la siguiente iteracion (es decir, enfriamos la temperatura)
            si ya hemos sobrepasado el numero de exitos especificado */
         if (n_exitos >= max_exitos) break;
      }

      /* Informe en pantalla */
      printf("Iter:%3d, ",j);
      printf("T=%9.6f, Exitos:%5d, ",t,n_exitos);
      printf("SolActual =%4.0f, MejorSol =%4.0f \n",fobj_act,fobj_mejor);

      /* Enfriamiento proporcional de la temperatura */
      t *= TFACTR;

      /* Terminamos la ejecucion del algoritmo en el caso en que no se consiga
         ningun exito para una temperatura concreta */
      if (n_exitos == 0)
      break;
   }

   /* Copiamos la mejor solucion encontrada para devolverla */
   for (i=0; i<n_bits; i++)
      sol_act[i] = mejor_sol[i];

   /* Liberamos la memoria empleada */
   free (vecino);
   free (mejor_sol);
   return;
}
