#ifndef __ANNEAL_H
#define __ANNEAL_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/* Parametro para el enfriamiento de la temperatura por
   descenso proporcional*/
#define TFACTR 0.9

float Funcion_objetivo (int *, int);
void anneal (int *, int, int, float, float, float);

#endif
