
       AAAA    CCCC   OOOO   TTTTTT   SSSSS  PPPPP
      AA  AA  CC     OO  OO    TT    SS      PP  PP
      AAAAAA  CC     OO  OO    TT     SSSS   PPPPP
      AA  AA  CC     OO  OO    TT        SS  PP
      AA  AA   CCCC   OOOO     TT    SSSSS   PP

######################################################
##########    ACO algorithms for the TSP    ##########
######################################################

      Version: 1.0
      Author:  Thomas Stuetzle
      Copyright (c) Thomas Stuetzle, 2002


=========
CONTENTS
=========

Time measurement:
timer.c (you only need this one)
timer.h (and this one)
dos_timer.c (same as timer.c)
dos_timer.h (same as timer.c)
unix_timer.c (in case you want to use rusage instead, use this one)
unix_timer.h (in case you want to use rusage instead, use this one)



